export interface User {
  walletAddress: string;
  name?: string;
  experience: 'beginner' | 'intermediate' | 'advanced';
  needsOnboarding: boolean;
}

export interface Chat {
  chatId: string;
  title: string;
  messageCount: number;
  lastMessage?: string;
  lastMessageTime?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  gasFeePaid?: string;
  transactionHash?: string;
}

export interface ProjectFile {
  fileName: string;
  fileType: string;
  content?: string;
  hash?: string;
  scanStatus: 'pending' | 'safe' | 'issues' | 'error';
  slitherResults?: SlitherResults;
  createdAt: string;
}

export interface SlitherResults {
  score: number;
  findings: SlitherFinding[];
  analyzedAt: string;
}

export interface SlitherFinding {
  severity: 'High' | 'Medium' | 'Low' | 'Informational';
  title: string;
  description: string;
  location?: {
    filename: string;
    line: number;
  };
}

export interface FeeInfo {
  feeAmount: string; // ETH format (e.g., "0.001")
  feeAmountWei: string;
  treasuryAddress: string;
  network: string;
}

export interface FeeTransaction {
  transactionHash: string;
  chatId?: string;
  amount: string;
  status: 'pending' | 'confirmed' | 'failed';
  createdAt: string;
}

export interface JobUpdate {
  jobId: string;
  jobType: 'fee-verification' | 'code-analysis' | 'deployment';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress?: number;
  result?: any;
  error?: string;
}

// API Response types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface AuthResponse {
  success: boolean;
  user: User;
}

export interface ChatResponse {
  messages: Message[];
  projectFiles: ProjectFile[];
  title: string;
}

// Wallet types
export interface WalletState {
  isConnected: boolean;
  address?: string;
  balance?: string;
  chainId?: number;
}