import { ConnectButton as RainbowConnectButton } from '@rainbow-me/rainbowkit';
import React from 'react';

export const ConnectButton = () => {
  return <RainbowConnectButton />;
};
