'use client';

import { useState } from 'react';
import { useSendTransaction, useAccount } from 'wagmi';
import { parseEther } from 'viem';
import { useFees } from '@/hooks/useFees';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2, AlertTriangle, Zap, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';

interface FeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmed: (transactionHash: string) => void;
  message: string;
}