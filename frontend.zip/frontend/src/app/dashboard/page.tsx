// ====================
// File: src/app/dashboard/page.tsx
// ====================

'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useWallet } from '@/hooks/useWallet';
import { useChats } from '@/hooks/useChats';
import { useSocket } from '@/hooks/useSocket';
import { DashboardLayout } from '@/components/common/DashboardLayout';
import { ChatSidebar } from '@/components/chat/ChatSidebar';
import { ChatWindow } from '@/components/chat/ChatWindow';
import { ProjectPanel } from '@/components/project/ProjectPanel';
import { WelcomeScreen } from '@/components/common/WelcomeScreen';
import { OnboardingModal } from '@/components/wallet/OnboardingModal';

export default function DashboardPage() {
  const router = useRouter();
  const { isAuthenticated, needsOnboarding, user } = useWallet();
  const { activeChat, chats } = useChats();
  
  // Initialize socket connection
  useSocket();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      // Don't redirect immediately - let wallet connection load
      const timeout = setTimeout(() => {
        if (!isAuthenticated) {
          router.push('/');
        }
      }, 2000);
      
      return () => clearTimeout(timeout);
    }
  }, [isAuthenticated, router]);

  // Show loading state while checking authentication
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="spinner w-8 h-8 border-4 border-solideus-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Connecting to wallet...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <DashboardLayout>
        <div className="flex h-screen bg-background">
          {/* Left Sidebar - Chat List */}
          <div className="w-80 border-r bg-muted/30">
            <ChatSidebar />
          </div>

          {/* Main Content */}
          <div className="flex-1 flex">
            {/* Center - Chat Window */}
            <div className="flex-1 flex flex-col">
              {activeChat ? (
                <ChatWindow />
              ) : (
                <WelcomeScreen />
              )}
            </div>

            {/* Right Panel - Project Files (when active) */}
            {activeChat && (
              <div className="w-96 border-l bg-muted/10">
                <ProjectPanel />
              </div>
            )}
          </div>
        </div>
      </DashboardLayout>

      {/* Onboarding Modal */}
      {needsOnboarding && <OnboardingModal />}
    </>
  );
}